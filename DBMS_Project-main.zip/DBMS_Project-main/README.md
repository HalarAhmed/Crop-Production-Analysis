# DBMS_Project
A semester project for Database Management System Course.
